# FreakSwap browser interpreter snapshot

This is the complete source snapshot used for `unicorn_arm.js` in the modular prototype.

- Unicorn.js source: commit 1220477c7fb0f8fe4b500f4bd211de52f6dfe638.
- Unicorn source: commit 8028ec436f2d9376525352dd38ed9ed6b9f6be10.
- The upstream JavaScript project's TCI, helper adapters and architecture symbol changes have already been applied; the needed TCI source files from its `externals/` tree are included.
- Local correction: in `qemu/tcg/tcg.c`, release the temporary i64 values introduced when widening helper-call arguments after the call operation has been emitted. Leaving them allocated exhausts TCG_MAX_TEMPS in long Thumb blocks. The fix changes interpreter translation bookkeeping; it does not modify the emulated MicroFreak firmware.
- Build settings: ARM-only, 1 MiB WASM stack, assertions in the JavaScript runtime, function names for diagnostics, file-prefix mapping to avoid embedding local build paths, four build jobs, incremental CMake build.

Build with Python 3, CMake 3.31.6, Make and Emscripten 6.0.11 available on PATH:

```
python3 build-prototype.py
```

The result is `dist/unicorn_arm.js`. Emscripten embeds WASM into that file. The snapshot is already patched; use the command above instead of rerunning the original patch-application stage. This source archive intentionally excludes Git metadata and build output. The emulator and wrapper retain their upstream GPLv2 license and notices.
