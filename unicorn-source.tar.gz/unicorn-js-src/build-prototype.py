#!/usr/bin/env python3
"""Build the included, already-patched ARM browser interpreter snapshot.

Requires Python 3, CMake 3.31+, Make, and Emscripten 6.0.11 on PATH.
The vendored sources already contain the upstream TCI/helper patches and the
translator temporary-lifetime fix; do not apply those patches a second time.
"""
import os,shutil
from pathlib import Path
os.chdir(Path(__file__).parent)
# This Unicorn configuration does not consume external pkg-config packages.
if not shutil.which('pkg-config'):
    os.environ.setdefault('PKG_CONFIG','/usr/bin/false')
import build
build.generateConstants()
build.compileUnicorn(['arm'])
