# Installation guide · MicroFreak Lite

Experimental firmware for MicroFreak 5.0.0.2084.

1. Back up your presets and keep a copy of the official firmware.
2. Open MIDI Control Center and connect your MicroFreak.
3. Load the downloaded .mff file following the firmware update procedure for your instrument.
4. Try the replacement engine and your presets.

## Selected engines

- Waveshaper → Swarm (Main). Wave: Spread; Timbre: Density; Shape: Size.
- Two Op FM → Wave Terrain · 5 terrains (Alternative (AUX)). Wave: Terrain; Timbre: Radius; Shape: Offset.
- Formant → Classic Waveshapes + VCF (Main). Wave: Response; Timbre: Cutoff; Shape: Shape.
- Chords → String Machine (Main). Wave: Chord; Timbre: Bright/Ens; Shape: Register.
- Speech → Phase Distortion (Main). Wave: Ratio; Timbre: Amount; Shape: Distort.
- Modal → Filtered Noise (Two-band (AUX)). Wave: Response; Timbre: Grain; Shape: Resonance.

All other engines stay unchanged. Presets that used a replaced engine may sound different.

This tool prepares the file. Install it manually with MIDI Control Center.
