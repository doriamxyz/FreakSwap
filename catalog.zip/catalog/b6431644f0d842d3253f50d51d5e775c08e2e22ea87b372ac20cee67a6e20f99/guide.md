# Installation guide · MicroFreak Lite

Experimental firmware for MicroFreak 5.0.0.2084.

1. Back up your presets and keep a copy of the official firmware.
2. Open MIDI Control Center and connect your MicroFreak.
3. Load the downloaded .mff file following the firmware update procedure for your instrument.
4. Try the replacement engine and your presets.

## Selected engines

- Speech → Phase Distortion (Main). Wave: Ratio; Timbre: Amount; Shape: Distort.
- Sample → Swarm (Main). Wave: Spread; Timbre: Density; Shape: Size.

All other engines stay unchanged. Presets that used a replaced engine may sound different.

This tool prepares the file. Install it manually with MIDI Control Center.
