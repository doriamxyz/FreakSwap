# Six-Op FM A/B/C installation

Experimental MicroFreak firmware 5.0.0.2084. Physical testing of this exact update is pending.

1. Back up your presets and keep the official firmware.
2. Prepare the firmware using the official 5.0.0.2084 file.
3. Install the downloaded .mff manually with MIDI Control Center.
4. Check A (Two Op. FM), B (Formant), C (Speech), four-note chords, patch changes, Shift controls, saving and reloading, and return from stock engines.

Type chooses the bank. Wave selects one of 32 named patches. Timbre controls brightness; Shape controls the envelope. Hold Shift with Type / Wave / Timbre / Shape for Algorithm / Feedback / Detune / Release.

A/B/C occupy three fixed slots together; the other engines remain unchanged. The DX LFO and second internal voice are omitted. Four MicroFreak voices are retained.

Presets from earlier Six-Op versions require choosing the bank and patch again, then saving a copy. Existing presets using the three replaced stock engines will sound different.

This update tracks the current audio-rate tuning coefficient in every render block, preserving the sounding voice state. Local emulation checks do not establish hardware boot order, real-time CPU or physical clock behavior.
